
const wheel = document.getElementById("wheel");
const spinButton = document.getElementById("spinButton");
const result = document.getElementById("result");
const prizes = ["200 نقطة", "100 نقطة", "50 نقطة", "20 نقطة", "جائزة مفاجأة", "10 نقطة"];

spinButton.addEventListener("click", () => {
    spinButton.disabled = true;
    result.textContent = "العجلة تدور... 🎡";

    const randomAngle = Math.floor(Math.random() * 360) + 3600;
    const sectionAngle = 360 / prizes.length;
    const prizeIndex = Math.floor(((randomAngle % 360) / sectionAngle));

    wheel.style.transition = "transform 4s ease-out";
    wheel.style.transform = `rotate(${randomAngle}deg)`;

    setTimeout(() => {
        result.textContent = `تهانينا! ربحت ${prizes[prizeIndex]} 🎉`;
        spinButton.disabled = false;
    }, 4000);
});
